// Chrome Extension Shared Types
export {};

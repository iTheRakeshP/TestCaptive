(() => {
  // src/background.ts
  console.log("TestCaptive: Background script starting (enterprise mode)...");
  var isRecording = false;
  var currentSessionId = null;
  var recordedEvents = [];
  var persistTimer = null;
  var MAX_EVENTS = 1e4;
  var PERSIST_DEBOUNCE_MS = 500;
  function persistState() {
    if (persistTimer) clearTimeout(persistTimer);
    persistTimer = setTimeout(() => {
      chrome.storage.local.set({
        "tc_isRecording": isRecording,
        "tc_sessionId": currentSessionId,
        "tc_events": recordedEvents
      });
    }, PERSIST_DEBOUNCE_MS);
  }
  function persistStateImmediate() {
    if (persistTimer) clearTimeout(persistTimer);
    chrome.storage.local.set({
      "tc_isRecording": isRecording,
      "tc_sessionId": currentSessionId,
      "tc_events": recordedEvents
    });
  }
  function clearPersistedState() {
    if (persistTimer) clearTimeout(persistTimer);
    chrome.storage.local.remove(["tc_isRecording", "tc_sessionId", "tc_events"]);
  }
  async function restoreState() {
    try {
      const data = await chrome.storage.local.get(["tc_isRecording", "tc_sessionId", "tc_events"]);
      if (data.tc_isRecording) {
        isRecording = true;
        currentSessionId = data.tc_sessionId || null;
        recordedEvents = data.tc_events || [];
        console.log("\u267B\uFE0F Restored recording state:", recordedEvents.length, "events");
      }
    } catch (e) {
      console.warn("Failed to restore state:", e);
    }
  }
  restoreState();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("TestCaptive: Message received:", message.type);
    switch (message.type) {
      case "ping":
        sendResponse({
          success: true,
          message: "pong from TestCaptive",
          isRecording
        });
        break;
      case "start-recording":
        isRecording = true;
        currentSessionId = "session_" + Date.now();
        recordedEvents = [];
        console.log("\u{1F534} Recording started:", currentSessionId);
        persistStateImmediate();
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const activeTab = tabs[0];
          if (activeTab?.url) {
            recordedEvents.push({
              type: "navigation",
              timestamp: (/* @__PURE__ */ new Date()).toISOString(),
              page: {
                url: activeTab.url,
                title: activeTab.title || ""
              },
              element: {
                tag: "window",
                id: "",
                className: "",
                text: "",
                value: "",
                type: "",
                name: "",
                placeholder: "",
                testid: "",
                ariaLabel: "",
                role: "",
                xpath: ""
              },
              sessionId: currentSessionId
            });
          }
          if (activeTab?.id) {
            chrome.tabs.sendMessage(activeTab.id, {
              type: "start-recording",
              sessionId: currentSessionId
            }).catch(() => {
            });
          }
        });
        sendResponse({ success: true, sessionId: currentSessionId });
        break;
      case "stop-recording":
        isRecording = false;
        console.log("\u23F9\uFE0F Recording stopped. Total events:", recordedEvents.length);
        clearPersistedState();
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]?.id) {
            chrome.tabs.sendMessage(tabs[0].id, { type: "stop-recording" }).catch(() => {
            });
          }
        });
        sendResponse({
          success: true,
          events: recordedEvents,
          sessionId: currentSessionId
        });
        break;
      case "event-captured":
        if (isRecording && recordedEvents.length < MAX_EVENTS) {
          recordedEvents.push(message.data);
          console.log("\u{1F4E5} Event stored. Total:", recordedEvents.length);
          persistState();
        } else if (recordedEvents.length >= MAX_EVENTS) {
          console.warn("\u26A0\uFE0F Max events reached, ignoring new events");
        }
        break;
      case "get-status":
        sendResponse({
          isRecording,
          eventCount: recordedEvents.length,
          sessionId: currentSessionId
        });
        break;
    }
    return true;
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!isRecording || !currentSessionId) return;
    if (changeInfo.status !== "complete" || !tab.url) return;
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id !== tabId) return;
      const lastEvent = recordedEvents[recordedEvents.length - 1];
      if (lastEvent?.type === "navigation" && lastEvent?.page?.url === tab.url) return;
      recordedEvents.push({
        type: "navigation",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        page: {
          url: tab.url,
          title: tab.title || ""
        },
        element: {
          tag: "window",
          id: "",
          className: "",
          text: "",
          value: "",
          type: "",
          name: "",
          placeholder: "",
          testid: "",
          ariaLabel: "",
          role: "",
          xpath: ""
        },
        sessionId: currentSessionId
      });
      console.log("\u{1F9ED} Tab navigation captured:", tab.url);
      chrome.tabs.sendMessage(tabId, {
        type: "start-recording",
        sessionId: currentSessionId
      }).catch(() => {
        chrome.scripting.executeScript({
          target: { tabId },
          files: ["content.js"]
        }).then(() => {
          setTimeout(() => {
            chrome.tabs.sendMessage(tabId, {
              type: "start-recording",
              sessionId: currentSessionId
            }).catch(() => {
            });
          }, 200);
        }).catch(() => {
        });
      });
    });
  });
  chrome.tabs.onCreated.addListener((tab) => {
    if (!isRecording || !currentSessionId) return;
    const newTabId = tab.id;
    if (!newTabId) return;
    recordedEvents.push({
      type: "new-tab",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      page: {
        url: tab.pendingUrl || tab.url || "about:blank",
        title: ""
      },
      element: {
        tag: "window",
        id: "",
        className: "",
        text: "",
        value: "",
        type: "",
        name: "",
        placeholder: "",
        testid: "",
        ariaLabel: "",
        role: "",
        xpath: ""
      },
      sessionId: currentSessionId,
      tabId: newTabId,
      windowId: tab.windowId
    });
    console.log("\u{1F195} New tab detected:", tab.pendingUrl || tab.url);
    persistState();
    const onTabReady = (tabId, changeInfo) => {
      if (tabId !== newTabId || changeInfo.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(onTabReady);
      chrome.scripting.executeScript({
        target: { tabId: newTabId },
        files: ["content.js"]
      }).then(() => {
        setTimeout(() => {
          chrome.tabs.sendMessage(newTabId, {
            type: "start-recording",
            sessionId: currentSessionId
          }).catch(() => {
          });
        }, 200);
      }).catch(() => {
      });
    };
    chrome.tabs.onUpdated.addListener(onTabReady);
  });
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "testcaptive-assertions",
      title: "\u2705 TestCaptive Assertions",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-text-equals",
      parentId: "testcaptive-assertions",
      title: "Assert Text Equals...",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-text-contains",
      parentId: "testcaptive-assertions",
      title: "Assert Text Contains...",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-visible",
      parentId: "testcaptive-assertions",
      title: "Assert Element Visible",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-not-visible",
      parentId: "testcaptive-assertions",
      title: "Assert Element Not Visible",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-enabled",
      parentId: "testcaptive-assertions",
      title: "Assert Element Enabled",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-disabled",
      parentId: "testcaptive-assertions",
      title: "Assert Element Disabled",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-url-contains",
      parentId: "testcaptive-assertions",
      title: "Assert URL Contains...",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-url-equals",
      parentId: "testcaptive-assertions",
      title: "Assert URL Equals...",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "assert-attribute-equals",
      parentId: "testcaptive-assertions",
      title: "Assert Attribute Equals...",
      contexts: ["all"]
    });
    console.log("\u2705 Context menus created");
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (!isRecording || !tab?.id) {
      console.log("\u26A0\uFE0F Cannot add assertion: Not recording");
      return;
    }
    const assertionType = info.menuItemId;
    if (assertionType === "assert-text-equals" || assertionType === "assert-text-contains" || assertionType === "assert-url-contains" || assertionType === "assert-url-equals" || assertionType === "assert-attribute-equals") {
      chrome.tabs.sendMessage(tab.id, {
        type: "create-text-assertion",
        assertionType
      }).catch(() => {
      });
    } else {
      chrome.tabs.sendMessage(tab.id, {
        type: "create-simple-assertion",
        assertionType
      }).catch(() => {
      });
    }
  });
})();

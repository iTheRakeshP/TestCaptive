// TestCaptive Enterprise Background Service Worker

console.log('TestCaptive: Background script starting (enterprise mode)...');

// ===== Core State =====
var isRecording = false;
var currentSessionId = null;
var recordedEvents = [];
var MAX_EVENTS = 10000;

// ===== Message Listener =====
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  console.log('TestCaptive: Message received:', message.type);

  switch (message.type) {
    case 'ping':
      sendResponse({ success: true, message: 'pong from TestCaptive', isRecording: isRecording });
      break;

    case 'start-recording':
      isRecording = true;
      currentSessionId = 'session_' + Date.now();
      recordedEvents = [];
      console.log('🔴 Recording started:', currentSessionId);

      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        var activeTab = tabs[0];
        if (activeTab && activeTab.url) {
          recordedEvents.push({
            type: 'navigation',
            timestamp: new Date().toISOString(),
            page: { url: activeTab.url, title: activeTab.title || '' },
            element: { tag: 'window', id: '', className: '', text: '', value: '', type: '', name: '', placeholder: '', testid: '', ariaLabel: '', role: '', xpath: '' },
            sessionId: currentSessionId
          });
        }
        if (activeTab && activeTab.id) {
          chrome.tabs.sendMessage(activeTab.id, { type: 'start-recording', sessionId: currentSessionId }).catch(function() {});
        }
      });

      sendResponse({ success: true, sessionId: currentSessionId });
      break;

    case 'stop-recording':
      isRecording = false;
      console.log('⏹️ Recording stopped. Total events:', recordedEvents.length);

      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'stop-recording' }).catch(function() {});
        }
      });

      sendResponse({ success: true, events: recordedEvents, sessionId: currentSessionId });
      break;

    case 'event-captured':
      if (isRecording && recordedEvents.length < MAX_EVENTS) {
        recordedEvents.push(message.data);
        console.log('📥 Event stored. Total:', recordedEvents.length);
      } else if (recordedEvents.length >= MAX_EVENTS) {
        console.warn('⚠️ Max events reached, ignoring new events');
      }
      break;

    case 'get-status':
      sendResponse({ isRecording: isRecording, eventCount: recordedEvents.length, sessionId: currentSessionId });
      break;
  }
  return true;
});

// ===== Tab Navigation Tracking =====
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (!isRecording || !currentSessionId) return;
  if (changeInfo.status !== 'complete' || !tab.url) return;

  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    if (!tabs[0] || tabs[0].id !== tabId) return;

    // Avoid duplicating navigations
    var lastEvent = recordedEvents[recordedEvents.length - 1];
    if (lastEvent && lastEvent.type === 'navigation' && lastEvent.page && lastEvent.page.url === tab.url) return;

    recordedEvents.push({
      type: 'navigation',
      timestamp: new Date().toISOString(),
      page: { url: tab.url, title: tab.title || '' },
      element: { tag: 'window', id: '', className: '', text: '', value: '', type: '', name: '', placeholder: '', testid: '', ariaLabel: '', role: '', xpath: '' },
      sessionId: currentSessionId
    });

    console.log('🧭 Tab navigation captured:', tab.url);

    // Re-inject content script on new page
    chrome.tabs.sendMessage(tabId, { type: 'start-recording', sessionId: currentSessionId }).catch(function() {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      }).then(function() {
        setTimeout(function() {
          chrome.tabs.sendMessage(tabId, { type: 'start-recording', sessionId: currentSessionId }).catch(function() {});
        }, 200);
      }).catch(function() {});
    });
  });
});

// ===== Context Menu for Assertions =====
chrome.runtime.onInstalled.addListener(function() {
  chrome.contextMenus.create({ id: 'testcaptive-assertions', title: '✅ TestCaptive Assertions', contexts: ['all'] });

  chrome.contextMenus.create({ id: 'assert-text-equals', parentId: 'testcaptive-assertions', title: 'Assert Text Equals...', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-text-contains', parentId: 'testcaptive-assertions', title: 'Assert Text Contains...', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-visible', parentId: 'testcaptive-assertions', title: 'Assert Element Visible', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-not-visible', parentId: 'testcaptive-assertions', title: 'Assert Element Not Visible', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-enabled', parentId: 'testcaptive-assertions', title: 'Assert Element Enabled', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-disabled', parentId: 'testcaptive-assertions', title: 'Assert Element Disabled', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-url-contains', parentId: 'testcaptive-assertions', title: 'Assert URL Contains...', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-url-equals', parentId: 'testcaptive-assertions', title: 'Assert URL Equals...', contexts: ['all'] });
  chrome.contextMenus.create({ id: 'assert-attribute-equals', parentId: 'testcaptive-assertions', title: 'Assert Attribute Equals...', contexts: ['all'] });

  console.log('✅ Context menus created');
});

chrome.contextMenus.onClicked.addListener(function(info, tab) {
  if (!isRecording || !tab || !tab.id) {
    console.log('⚠️ Cannot add assertion: Not recording');
    return;
  }

  var assertionType = info.menuItemId;

  if (assertionType === 'assert-text-equals' || assertionType === 'assert-text-contains' ||
      assertionType === 'assert-url-contains' || assertionType === 'assert-url-equals' ||
      assertionType === 'assert-attribute-equals') {
    chrome.tabs.sendMessage(tab.id, { type: 'create-text-assertion', assertionType: assertionType }).catch(function() {});
  } else {
    chrome.tabs.sendMessage(tab.id, { type: 'create-simple-assertion', assertionType: assertionType }).catch(function() {});
  }
});

// TestCaptive Enterprise Content Script
// Captures DOM events, generates selectors, detects SPA navigation,
// supports Shadow DOM, iframes, file uploads, drag-drop, dialogs,
// and provides PII redaction for sensitive fields.

(function () {
  'use strict';

  // Prevent multiple loads
  if (window.__TESTCAPTIVE_LOADED__) return;
  window.__TESTCAPTIVE_LOADED__ = true;

  console.log('🎯 TestCaptive Content Script Loaded');

  // ===== Detection Flag =====
  function setDetectionFlag() {
    window.testCaptiveContentScript = true;
    try { sessionStorage.setItem('testCaptiveActive', 'true'); } catch (_) {}
    try {
      if (document.head && !document.getElementById('__testcaptive_flag__')) {
        const flag = document.createElement('meta');
        flag.id = '__testcaptive_flag__';
        flag.name = 'testcaptive-detected';
        flag.content = 'true';
        document.head.appendChild(flag);
      }
    } catch (_) {}
  }
  setDetectionFlag();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setDetectionFlag);
  }
  window.addEventListener('load', setDetectionFlag);

  // ===== Constants =====
  var MAX_EVENTS = 10000;
  var SCROLL_DEBOUNCE = 300;
  var FILL_COMMIT_DELAY = 1500; // Commit fill after 1500ms of inactivity

  // ===== PII / Sensitive Data Redaction =====
  const SENSITIVE_INPUT_TYPES = new Set([
    'password', 'credit-card', 'cc-number', 'cc-exp', 'cc-csc', 'ssn'
  ]);
  const SENSITIVE_AUTOCOMPLETE_VALUES = new Set([
    'cc-number', 'cc-exp', 'cc-exp-month', 'cc-exp-year', 'cc-csc',
    'cc-name', 'cc-type', 'new-password', 'current-password'
  ]);
  const SENSITIVE_NAME_PATTERNS = /password|passwd|pwd|secret|token|ssn|social.?security|credit.?card|card.?number|cvv|cvc|csc|expir/i;

  function isSensitiveField(element) {
    const inputType = (element.type || '').toLowerCase();
    if (SENSITIVE_INPUT_TYPES.has(inputType)) return true;
    const autocomplete = (element.getAttribute('autocomplete') || '').toLowerCase();
    if (SENSITIVE_AUTOCOMPLETE_VALUES.has(autocomplete)) return true;
    const name = element.name || '';
    const id = element.id || '';
    const placeholder = element.placeholder || '';
    const ariaLabel = element.getAttribute('aria-label') || '';
    return SENSITIVE_NAME_PATTERNS.test(name) || SENSITIVE_NAME_PATTERNS.test(id) ||
           SENSITIVE_NAME_PATTERNS.test(placeholder) || SENSITIVE_NAME_PATTERNS.test(ariaLabel);
  }

  function redactIfSensitive(value, element) {
    if (!value) return value;
    if (isSensitiveField(element)) return '[REDACTED]';
    return value;
  }

  // ===== Dynamic ID / Class Detection =====
  const DYNAMIC_ID_PATTERNS = [
    /^:r[0-9a-z]+:$/,
    /^react-/,
    /^ng-/,
    /^_ng[a-z]+-/,
    /^mat-/,
    /^cdk-/,
    /^ember\d+$/,
    /^__next/,
    /^[a-z]{1,3}-[a-f0-9]{4,}$/i,
    /^[0-9a-f]{8}-[0-9a-f]{4}/,
    /^\d+$/,
  ];
  const DYNAMIC_CLASS_PATTERNS = [
    /^css-[a-z0-9]+$/,
    /^sc-[a-zA-Z]+$/,
    /^_[a-zA-Z0-9]{5,}$/,
    /^svelte-[a-z0-9]+$/,
    /^tw-[a-z0-9]+$/,
  ];

  function isDynamicId(id) {
    if (!id) return false;
    return DYNAMIC_ID_PATTERNS.some(function(p) { return p.test(id); });
  }

  function isDynamicClass(className) {
    if (!className) return false;
    return DYNAMIC_CLASS_PATTERNS.some(function(p) { return p.test(className); });
  }

  // ===== Selector Generation =====
  function escapeCSSValue(value) {
    return value.replace(/([!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, '\\$1');
  }

  function generateSelector(element) {
    // 1. data-testid
    var testId = element.getAttribute('data-testid') || element.getAttribute('data-test-id');
    if (testId) return '[data-testid="' + escapeCSSValue(testId) + '"]';

    // 2. aria-label
    var ariaLabel = element.getAttribute('aria-label');
    if (ariaLabel) return '[aria-label="' + escapeCSSValue(ariaLabel) + '"]';

    // 3. Stable ID
    if (element.id && !isDynamicId(element.id)) return '#' + escapeCSSValue(element.id);

    // 4. name attribute
    var name = element.getAttribute('name');
    if (name) return element.tagName.toLowerCase() + '[name="' + escapeCSSValue(name) + '"]';

    // 5. Role
    var role = element.getAttribute('role');
    if (role) return '[role="' + role + '"]';

    // 6. Stable class-based selector
    var tag = element.tagName.toLowerCase();
    if (element.className && typeof element.className === 'string') {
      var stableClasses = element.className.split(' ')
        .filter(function(c) { return c.trim() && !isDynamicClass(c.trim()); })
        .slice(0, 2);
      if (stableClasses.length > 0) {
        var selector = tag + '.' + stableClasses.map(function(c) { return escapeCSSValue(c); }).join('.');
        var parent = element.parentElement;
        if (parent) {
          var siblings = Array.from(parent.children).filter(function(el) { return el.tagName === element.tagName; });
          if (siblings.length > 1) {
            var index = siblings.indexOf(element) + 1;
            selector += ':nth-child(' + index + ')';
          }
        }
        return selector;
      }
    }

    // 7. Fallback
    var parentEl = element.parentElement;
    if (parentEl) {
      var sibs = Array.from(parentEl.children).filter(function(el) { return el.tagName === element.tagName; });
      if (sibs.length > 1) {
        var idx = sibs.indexOf(element) + 1;
        return tag + ':nth-child(' + idx + ')';
      }
    }
    return tag;
  }

  // ===== XPath Generation =====
  function generateXPath(element) {
    if (element.id && !isDynamicId(element.id)) return '//*[@id="' + element.id + '"]';
    var testId = element.getAttribute('data-testid') || element.getAttribute('data-test-id');
    if (testId) return '//*[@data-testid="' + testId + '"]';
    if (element === document.body) return '/html/body';
    if (element === document.documentElement) return '/html';

    var ix = 0;
    var siblings = element.parentNode ? element.parentNode.childNodes : [];
    for (var i = 0; i < siblings.length; i++) {
      var sibling = siblings[i];
      if (sibling === element) {
        var parentXPath = element.parentNode && element.parentNode !== document
          ? generateXPath(element.parentNode) : '';
        return parentXPath + '/' + element.tagName.toLowerCase() + '[' + (ix + 1) + ']';
      }
      if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;
    }
    return '';
  }

  // ===== Shadow DOM Support =====
  function getShadowHostPath(element) {
    var root = element.getRootNode();
    if (root instanceof ShadowRoot) {
      var host = root.host;
      var hostSelector = generateSelector(host);
      var parentPath = getShadowHostPath(host);
      return parentPath ? parentPath + ' >> ' + hostSelector : hostSelector;
    }
    return null;
  }

  // ===== Element Info Builder =====
  function getElementInfo(element) {
    return {
      tag: (element.tagName || '').toLowerCase(),
      id: element.id || '',
      className: (typeof element.className === 'string' ? element.className : '') || '',
      text: (element.textContent || '').substring(0, 100).trim(),
      value: element.value || '',
      type: element.type || '',
      name: element.name || '',
      placeholder: element.placeholder || '',
      testid: element.getAttribute('data-testid') || element.getAttribute('data-test-id') || '',
      ariaLabel: element.getAttribute('aria-label') || '',
      role: element.getAttribute('role') || '',
      xpath: generateXPath(element),
      cssSelector: generateSelector(element),
      checked: element.checked,
      href: element.href || '',
      src: element.src || '',
      isContentEditable: element.isContentEditable || false
    };
  }

  // ===== State =====
  var isRecording = false;
  var sessionId = null;
  var recordedEvents = [];
  var rightClickedElement = null;

  // Action builder state (Playwright codegen-style)
  var pendingFill = null; // { element, selector, elementInfo, timestamp, value, page, position, iframeContext }
  var fillCommitTimer = null;

  var scrollDebounceTimer = null;
  var lastScrollPosition = { x: 0, y: 0 };
  var lastEmittedEvent = null;
  var lastUrl = window.location.href;

  var originalAlert, originalConfirm, originalPrompt;

  // ===== Helpers =====

  /** Check if an element is a text-like input that should use fill() */
  function isTextLikeInput(element) {
    var tag = element.tagName;
    if (tag === 'TEXTAREA') return true;
    if (element.isContentEditable) return true;
    if (tag === 'INPUT') {
      var type = (element.type || 'text').toLowerCase();
      return ['text', 'password', 'email', 'search', 'tel', 'url', 'number'].indexOf(type) !== -1;
    }
    return false;
  }

  // ===== Pending Fill Management =====

  function commitPendingFill() {
    if (fillCommitTimer) { clearTimeout(fillCommitTimer); fillCommitTimer = null; }
    if (!pendingFill) return;

    if (pendingFill.value) {
      var safeValue = redactIfSensitive(pendingFill.value, pendingFill.element);
      var elementInfo = Object.assign({}, pendingFill.elementInfo);
      if (isSensitiveField(pendingFill.element)) { elementInfo.value = '[REDACTED]'; }

      emitEvent({
        type: 'fill',
        timestamp: pendingFill.timestamp,
        element: elementInfo,
        page: pendingFill.page,
        sessionId: sessionId,
        selector: pendingFill.selector,
        inputValue: safeValue,
        position: pendingFill.position,
        iframeContext: pendingFill.iframeContext
      });
    }
    pendingFill = null;
  }

  function scheduleFillCommit() {
    if (fillCommitTimer) clearTimeout(fillCommitTimer);
    fillCommitTimer = setTimeout(commitPendingFill, FILL_COMMIT_DELAY);
  }

  // ===== Core Event Emission =====

  function emitEvent(eventData) {
    if (recordedEvents.length >= MAX_EVENTS) {
      console.warn('⚠️ TestCaptive: Max events (' + MAX_EVENTS + ') reached.');
      return;
    }

    // Basic dedup: skip exact same event type + selector within 150ms
    var now = Date.now();
    if (lastEmittedEvent &&
        lastEmittedEvent.type === eventData.type &&
        lastEmittedEvent.selector === (eventData.selector || '') &&
        (now - lastEmittedEvent.timestamp) < 150) {
      return;
    }

    recordedEvents.push(eventData);
    lastEmittedEvent = { type: eventData.type, selector: eventData.selector || '', timestamp: now };

    try {
      chrome.runtime.sendMessage({ type: 'event-captured', data: eventData });
    } catch (e) {
      console.warn('TestCaptive: Failed to send event to background:', e);
    }
    console.log('📤 Event captured:', eventData.type, eventData.element ? eventData.element.tag : '', eventData.inputValue || '');
  }

  // ===== Message Handler =====
  chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    switch (message.type) {
      case 'start-recording':
        startRecording(message.sessionId);
        sendResponse({ success: true });
        break;
      case 'stop-recording':
        commitPendingFill();
        sendResponse({ success: true, eventCount: stopRecording() });
        break;
      case 'ping':
        sendResponse({ success: true, isRecording: isRecording, sessionId: sessionId, eventCount: recordedEvents.length });
        break;
      case 'add-assertion':
        if (isRecording && message.assertion) {
          addAssertion(message.assertion);
          sendResponse({ success: true });
        } else {
          sendResponse({ success: false, error: 'Not recording or invalid assertion' });
        }
        break;
      case 'create-text-assertion':
        if (isRecording && rightClickedElement) {
          createTextAssertion(message.assertionType, rightClickedElement);
          sendResponse({ success: true });
        } else {
          sendResponse({ success: false });
        }
        break;
      case 'create-simple-assertion':
        if (isRecording && rightClickedElement) {
          createSimpleAssertion(message.assertionType, rightClickedElement);
          sendResponse({ success: true });
        } else {
          sendResponse({ success: false });
        }
        break;
      default:
        sendResponse({ success: false, error: 'Unknown message type' });
    }
    return true;
  });

  // ===== Recording Lifecycle =====
  function startRecording(newSessionId) {
    isRecording = true;
    sessionId = newSessionId;
    recordedEvents = [];
    pendingFill = null;
    if (fillCommitTimer) { clearTimeout(fillCommitTimer); fillCommitTimer = null; }
    lastEmittedEvent = null;
    lastUrl = window.location.href;

    attachEventListeners();
    attachSPAListeners();
    attachDialogInterceptors();
    highlightRecordableElements();
    console.log('🔴 Recording started:', sessionId);
  }

  function stopRecording() {
    isRecording = false;
    var eventCount = recordedEvents.length;
    removeEventListeners();
    removeSPAListeners();
    removeDialogInterceptors();
    removeHighlights();
    console.log('⏹️ Recording stopped. Events captured:', eventCount);
    sessionId = null;
    recordedEvents = [];
    return eventCount;
  }

  // ===== Smart Event Capture (Playwright codegen-style) =====
  function captureEvent(event) {
    if (!isRecording || !sessionId) return;

    try {
      var element = event.target;
      if (!element || !element.tagName) return;

      var eventType = event.type;

      // ---- Focus / Blur: only used as commit triggers, never emitted ----
      if (eventType === 'focus') {
        if (pendingFill && element !== pendingFill.element) { commitPendingFill(); }
        return;
      }
      if (eventType === 'blur') {
        if (pendingFill && element === pendingFill.element) { commitPendingFill(); }
        return;
      }

      // ---- Build common event data ----
      var rect = element.getBoundingClientRect();
      var elementInfo = getElementInfo(element);
      var iframeCtx = getIframeContext();
      var selector = generateSelector(element);
      var shadowPath = getShadowHostPath(element);
      var fullSelector = shadowPath ? shadowPath + ' >> ' + selector : selector;

      var page = {
        url: window.location.href,
        title: document.title,
        scrollX: window.scrollX,
        scrollY: window.scrollY
      };

      var position = {
        x: Math.round(rect.left + window.scrollX),
        y: Math.round(rect.top + window.scrollY),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      };

      // ---- Input event: accumulate into pending fill ----
      if (eventType === 'input') {
        handleSmartInput(element, elementInfo, fullSelector, page, position, iframeCtx || undefined);
        return;
      }

      // ---- Change event: select, checkbox, radio, file ----
      if (eventType === 'change') {
        handleSmartChange(element, elementInfo, fullSelector, page, position, iframeCtx || undefined);
        return;
      }

      // ---- Click event: smart routing ----
      if (eventType === 'click') {
        handleSmartClick(event, element, elementInfo, fullSelector, page, position, iframeCtx || undefined);
        return;
      }

      // ---- Double-click ----
      if (eventType === 'dblclick') {
        commitPendingFill();
        emitEvent({
          type: 'dblclick',
          timestamp: new Date().toISOString(),
          element: elementInfo,
          page: page,
          sessionId: sessionId,
          selector: fullSelector,
          position: position,
          iframeContext: iframeCtx || undefined
        });
        return;
      }

      // ---- Keydown: smart filtering ----
      if (eventType === 'keydown') {
        handleSmartKeydown(event, element, elementInfo, fullSelector, page, position, iframeCtx || undefined);
        return;
      }

      // ---- Submit ----
      if (eventType === 'submit') {
        commitPendingFill();
        emitEvent({
          type: 'submit',
          timestamp: new Date().toISOString(),
          element: elementInfo,
          page: page,
          sessionId: sessionId,
          selector: fullSelector,
          position: position,
          iframeContext: iframeCtx || undefined
        });
        return;
      }

    } catch (error) {
      console.error('TestCaptive: Error capturing event:', error);
    }
  }

  // ===== Smart Click Handler =====
  function handleSmartClick(event, element, elementInfo, selector, page, position, iframeContext) {
    if (isTextLikeInput(element)) {
      // Click on a text field: start pending fill, DON'T emit click
      if (pendingFill && pendingFill.element === element) { return; } // Re-clicked same field
      commitPendingFill();
      pendingFill = {
        element: element,
        selector: selector,
        elementInfo: elementInfo,
        timestamp: new Date().toISOString(),
        value: element.value || '',
        page: page,
        position: position,
        iframeContext: iframeContext
      };
      return;
    }

    // Click on <select> element: suppress (the 'select' change event captures the action)
    if (element.tagName === 'SELECT') {
      return;
    }

    // Non-text click: commit any pending fill, then emit click
    commitPendingFill();
    if (isSensitiveField(element)) { elementInfo.value = '[REDACTED]'; }

    emitEvent({
      type: 'click',
      timestamp: new Date().toISOString(),
      element: elementInfo,
      page: page,
      sessionId: sessionId,
      selector: selector,
      position: position,
      clickPosition: { clientX: event.clientX, clientY: event.clientY },
      iframeContext: iframeContext
    });
  }

  // ===== Smart Input Handler =====
  function handleSmartInput(element, elementInfo, selector, page, position, iframeContext) {
    if (element.tagName === 'SELECT' || element.type === 'checkbox' || element.type === 'radio') return;

    var currentValue = element.value || element.textContent || '';

    if (pendingFill && pendingFill.element === element) {
      pendingFill.value = currentValue;
      pendingFill.timestamp = new Date().toISOString();
      scheduleFillCommit();
    } else {
      commitPendingFill();
      pendingFill = {
        element: element,
        selector: selector,
        elementInfo: elementInfo,
        timestamp: new Date().toISOString(),
        value: currentValue,
        page: page,
        position: position,
        iframeContext: iframeContext
      };
      scheduleFillCommit();
    }
  }

  // ===== Smart Change Handler =====
  function handleSmartChange(element, elementInfo, selector, page, position, iframeContext) {
    var tag = element.tagName;

    // SELECT → emit 'select'
    if (tag === 'SELECT') {
      commitPendingFill();
      elementInfo.selectedOptions = Array.from(element.selectedOptions).map(function(o) { return o.text; });
      emitEvent({
        type: 'select',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        value: element.value,
        inputValue: element.value,
        position: position,
        iframeContext: iframeContext
      });
      return;
    }

    // Checkbox / Radio → emit 'check'
    if (element.type === 'checkbox' || element.type === 'radio') {
      commitPendingFill();
      elementInfo.checked = element.checked;
      emitEvent({
        type: 'check',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        value: String(element.checked),
        position: position,
        iframeContext: iframeContext
      });
      return;
    }

    // File input → emit 'file-upload'
    if (element.type === 'file' && element.files && element.files.length > 0) {
      commitPendingFill();
      emitEvent({
        type: 'file-upload',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        files: Array.from(element.files).map(function(f) { return { name: f.name, size: f.size, type: f.type }; }),
        position: position,
        iframeContext: iframeContext
      });
      return;
    }

    // Text-like change: ignore (handled by fill action)
  }

  // ===== Smart Keydown Handler =====
  function handleSmartKeydown(event, element, elementInfo, selector, page, position, iframeContext) {
    var key = event.key;

    // Tab: only commit trigger, never recorded
    if (key === 'Tab') { commitPendingFill(); return; }

    // Enter: context-dependent
    if (key === 'Enter') {
      if (isTextLikeInput(element)) { commitPendingFill(); }
      emitEvent({
        type: 'keydown',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        value: 'Enter',
        position: position,
        iframeContext: iframeContext
      });
      return;
    }

    // Escape: always capture
    if (key === 'Escape') {
      commitPendingFill();
      emitEvent({
        type: 'keydown',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        value: 'Escape',
        position: position,
        iframeContext: iframeContext
      });
      return;
    }

    // Keyboard shortcuts (Ctrl/Cmd + key)
    var isShortcut = event.ctrlKey || event.metaKey || event.altKey;
    if (isShortcut) {
      var parts = [];
      if (event.ctrlKey) parts.push('Control');
      if (event.altKey) parts.push('Alt');
      if (event.shiftKey) parts.push('Shift');
      if (event.metaKey) parts.push('Meta');
      parts.push(key);
      emitEvent({
        type: 'keydown',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        value: parts.join('+'),
        position: position,
        iframeContext: iframeContext
      });
      return;
    }

    // Other meaningful keys only outside text inputs
    var navigationKeys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight',
      'Home', 'End', 'PageUp', 'PageDown',
      'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'];
    if (navigationKeys.indexOf(key) !== -1 && !isTextLikeInput(element)) {
      emitEvent({
        type: 'keydown',
        timestamp: new Date().toISOString(),
        element: elementInfo,
        page: page,
        sessionId: sessionId,
        selector: selector,
        value: key,
        position: position,
        iframeContext: iframeContext
      });
    }
  }

  // ===== Scroll Tracking =====
  function handleScroll() {
    if (!isRecording || !sessionId) return;
    if (scrollDebounceTimer) clearTimeout(scrollDebounceTimer);
    scrollDebounceTimer = setTimeout(function() {
      var currentScroll = { x: window.scrollX, y: window.scrollY };
      var dx = Math.abs(currentScroll.x - lastScrollPosition.x);
      var dy = Math.abs(currentScroll.y - lastScrollPosition.y);
      if (dx < 200 && dy < 200) return;
      lastScrollPosition = currentScroll;

      emitEvent({
        type: 'scroll',
        timestamp: new Date().toISOString(),
        element: { tag: 'window', id: '', className: '', text: '', value: '', type: '', name: '', placeholder: '', testid: '', ariaLabel: '', role: '', xpath: '' },
        page: { url: window.location.href, title: document.title, scrollX: window.scrollX, scrollY: window.scrollY },
        sessionId: sessionId,
        scrollPosition: currentScroll
      });
    }, SCROLL_DEBOUNCE);
  }

  // ===== Drag & Drop =====
  var dragSourceElement = null;

  function handleDragStart(event) {
    if (!isRecording) return;
    dragSourceElement = event.target;
  }

  function handleDrop(event) {
    if (!isRecording || !sessionId || !dragSourceElement) return;
    var dropTarget = event.target;
    emitEvent({
      type: 'drag-drop',
      timestamp: new Date().toISOString(),
      element: getElementInfo(dropTarget),
      page: { url: window.location.href, title: document.title },
      sessionId: sessionId,
      selector: generateSelector(dropTarget),
      dragSource: generateSelector(dragSourceElement),
      dropTarget: generateSelector(dropTarget)
    });
    dragSourceElement = null;
  }

  // ===== Hover Tracking =====
  var hoverTimer = null;

  function handleMouseEnter(event) {
    if (!isRecording || !sessionId) return;
    var element = event.target;
    if (!isInteractiveHoverTarget(element)) return;
    if (hoverTimer) clearTimeout(hoverTimer);
    hoverTimer = setTimeout(function() {
      emitEvent({
        type: 'hover',
        timestamp: new Date().toISOString(),
        element: getElementInfo(element),
        page: { url: window.location.href, title: document.title },
        sessionId: sessionId,
        selector: generateSelector(element)
      });
    }, 500);
  }

  function handleMouseLeave() {
    if (hoverTimer) { clearTimeout(hoverTimer); hoverTimer = null; }
  }

  function isInteractiveHoverTarget(element) {
    var role = element.getAttribute && element.getAttribute('role');
    if (role && ['menu', 'menubar', 'menuitem', 'tooltip', 'listbox', 'option'].indexOf(role) !== -1) return true;
    var tag = (element.tagName || '').toLowerCase();
    if (tag === 'nav' || tag === 'menu') return true;
    if (element.getAttribute && element.getAttribute('aria-haspopup')) return true;
    return false;
  }

  // ===== SPA Navigation Detection =====
  function onSPANavigation() {
    if (!isRecording || !sessionId) return;
    var currentUrl = window.location.href;
    if (currentUrl === lastUrl) return;

    emitEvent({
      type: 'spa-navigation',
      timestamp: new Date().toISOString(),
      element: { tag: 'window', id: '', className: '', text: '', value: '', type: '', name: '', placeholder: '', testid: '', ariaLabel: '', role: '', xpath: '' },
      page: { url: currentUrl, title: document.title },
      sessionId: sessionId
    });
    lastUrl = currentUrl;
  }

  var originalPushState = history.pushState.bind(history);
  var originalReplaceState = history.replaceState.bind(history);

  function patchedPushState(state, title, url) {
    originalPushState(state, title, url);
    setTimeout(onSPANavigation, 0);
  }

  function patchedReplaceState(state, title, url) {
    originalReplaceState(state, title, url);
    setTimeout(onSPANavigation, 0);
  }

  function attachSPAListeners() {
    window.addEventListener('popstate', onSPANavigation);
    window.addEventListener('hashchange', onSPANavigation);
    history.pushState = patchedPushState;
    history.replaceState = patchedReplaceState;
  }

  function removeSPAListeners() {
    window.removeEventListener('popstate', onSPANavigation);
    window.removeEventListener('hashchange', onSPANavigation);
    history.pushState = originalPushState;
    history.replaceState = originalReplaceState;
  }

  // ===== Dialog Interception =====
  function attachDialogInterceptors() {
    originalAlert = window.alert;
    originalConfirm = window.confirm;
    originalPrompt = window.prompt;

    window.alert = function (message) {
      captureDialog('alert', String(message || ''), '');
      return originalAlert.call(window, message);
    };
    window.confirm = function (message) {
      var result = originalConfirm.call(window, message);
      captureDialog('confirm', message || '', String(result));
      return result;
    };
    window.prompt = function (message, defaultValue) {
      var result = originalPrompt.call(window, message, defaultValue);
      captureDialog('prompt', message || '', result || '');
      return result;
    };
  }

  function removeDialogInterceptors() {
    if (originalAlert) window.alert = originalAlert;
    if (originalConfirm) window.confirm = originalConfirm;
    if (originalPrompt) window.prompt = originalPrompt;
  }

  function captureDialog(dialogType, message, response) {
    if (!isRecording || !sessionId) return;
    emitEvent({
      type: 'dialog',
      timestamp: new Date().toISOString(),
      element: { tag: 'dialog', id: '', className: '', text: message, value: '', type: dialogType, name: '', placeholder: '', testid: '', ariaLabel: '', role: 'alertdialog', xpath: '' },
      page: { url: window.location.href, title: document.title },
      sessionId: sessionId,
      dialogType: dialogType,
      dialogMessage: message,
      dialogResponse: response
    });
  }

  // ===== Iframe Context =====
  function getIframeContext() {
    try {
      if (window === window.top) return null;
      var frame = window.frameElement;
      if (frame) {
        var id = frame.id || frame.getAttribute('name') || '';
        var src = frame.getAttribute('src') || '';
        return id || src || 'anonymous-iframe';
      }
      return 'cross-origin-iframe';
    } catch (_) {
      return 'cross-origin-iframe';
    }
  }

  // ===== Event Listener Management =====
  var coreEventTypes = ['click', 'dblclick', 'input', 'change', 'submit', 'focus', 'blur', 'keydown'];
  var eventHandlers = {};

  function attachEventListeners() {
    coreEventTypes.forEach(function(eventType) {
      eventHandlers[eventType] = function(e) { captureEvent(e); };
      document.addEventListener(eventType, eventHandlers[eventType], true);
    });

    window.addEventListener('scroll', handleScroll, { passive: true });
    document.addEventListener('dragstart', handleDragStart, true);
    document.addEventListener('drop', handleDrop, true);
    document.addEventListener('mouseenter', handleMouseEnter, true);
    document.addEventListener('mouseleave', handleMouseLeave, true);
    document.addEventListener('contextmenu', captureRightClick, true);

    console.log('🎯 Event listeners attached (enterprise mode)');
  }

  function removeEventListeners() {
    coreEventTypes.forEach(function(eventType) {
      if (eventHandlers[eventType]) {
        document.removeEventListener(eventType, eventHandlers[eventType], true);
      }
    });
    window.removeEventListener('scroll', handleScroll);
    document.removeEventListener('dragstart', handleDragStart, true);
    document.removeEventListener('drop', handleDrop, true);
    document.removeEventListener('mouseenter', handleMouseEnter, true);
    document.removeEventListener('mouseleave', handleMouseLeave, true);
    document.removeEventListener('contextmenu', captureRightClick, true);

    if (scrollDebounceTimer) clearTimeout(scrollDebounceTimer);
    if (hoverTimer) clearTimeout(hoverTimer);
  }

  // ===== Visual Highlighting =====
  function highlightRecordableElements() {
    if (!isRecording) return;
    var style = document.createElement('style');
    style.id = 'testcaptive-highlight-style';
    style.textContent = '.testcaptive-recordable { outline: 2px dashed #4CAF50 !important; outline-offset: 2px !important; } .testcaptive-recordable:hover { outline: 2px solid #4CAF50 !important; background-color: rgba(76, 175, 80, 0.1) !important; }';
    if (document.head) document.head.appendChild(style);

    var selector = 'button, input, select, textarea, a[href], [onclick], [role="button"], [tabindex], [draggable="true"], [contenteditable="true"]';
    document.querySelectorAll(selector).forEach(function(el) { el.classList.add('testcaptive-recordable'); });
    console.log('✨ Interactive elements highlighted');
  }

  function removeHighlights() {
    var style = document.getElementById('testcaptive-highlight-style');
    if (style) style.remove();
    document.querySelectorAll('.testcaptive-recordable').forEach(function(el) { el.classList.remove('testcaptive-recordable'); });
  }

  // ===== Assertion Functions =====
  function captureRightClick(event) {
    if (!isRecording) return;
    rightClickedElement = event.target;
  }

  function createTextAssertion(assertionType, element) {
    var elementInfo = getElementInfo(element);
    var expectedValue = '';

    if (assertionType === 'assert-text-equals' || assertionType === 'assert-text-contains') {
      expectedValue = prompt('Enter expected text for ' + assertionType + ':', (element.textContent || '').trim()) || '';
      if (!expectedValue) return;
    } else if (assertionType === 'assert-url-contains' || assertionType === 'assert-url-equals') {
      expectedValue = prompt('Enter expected URL or URL part:', window.location.href) || '';
      if (!expectedValue) return;
    } else if (assertionType === 'assert-attribute-equals') {
      var attrName = prompt('Enter attribute name:') || '';
      if (!attrName) return;
      var attrValue = prompt('Enter expected value for "' + attrName + '":', element.getAttribute(attrName) || '') || '';
      expectedValue = attrName + '=' + attrValue;
    }

    addAssertion({
      type: assertionType.replace('assert-', ''),
      description: getAssertionDescription(assertionType, expectedValue, elementInfo),
      expectedValue: expectedValue,
      timestamp: new Date().toISOString(),
      element: elementInfo
    });
  }

  function createSimpleAssertion(assertionType, element) {
    var elementInfo = getElementInfo(element);
    addAssertion({
      type: assertionType.replace('assert-', ''),
      description: getAssertionDescription(assertionType, null, elementInfo),
      timestamp: new Date().toISOString(),
      element: elementInfo
    });
  }

  function getAssertionDescription(type, value, elementInfo) {
    var elementDesc = elementInfo.testid ? '[testid="' + elementInfo.testid + '"]'
      : elementInfo.id ? '#' + elementInfo.id
      : elementInfo.text ? '"' + elementInfo.text.substring(0, 30) + '"'
      : elementInfo.tag;

    switch (type) {
      case 'assert-text-equals': return 'Assert ' + elementDesc + ' text equals "' + value + '"';
      case 'assert-text-contains': return 'Assert ' + elementDesc + ' text contains "' + value + '"';
      case 'assert-visible': return 'Assert ' + elementDesc + ' is visible';
      case 'assert-not-visible': return 'Assert ' + elementDesc + ' is not visible';
      case 'assert-enabled': return 'Assert ' + elementDesc + ' is enabled';
      case 'assert-disabled': return 'Assert ' + elementDesc + ' is disabled';
      case 'assert-url-contains': return 'Assert URL contains "' + value + '"';
      case 'assert-url-equals': return 'Assert URL equals "' + value + '"';
      case 'assert-attribute-equals': return 'Assert ' + elementDesc + ' attribute ' + value;
      default: return 'Assert ' + type;
    }
  }

  function addAssertion(assertion) {
    if (!isRecording || !sessionId) return;

    emitEvent({
      type: 'assertion',
      timestamp: new Date().toISOString(),
      sessionId: sessionId,
      assertion: assertion,
      element: assertion.element || { tag: 'assertion', id: '', className: '', text: '', value: '', type: '', name: '', placeholder: '', testid: '', ariaLabel: '', role: '', xpath: '' },
      page: { url: window.location.href, title: document.title }
    });

    console.log('✅ Assertion added:', assertion.type);
    showAssertionFeedback(assertion.description);
  }

  function showAssertionFeedback(description) {
    var feedback = document.createElement('div');
    feedback.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #4CAF50; color: white; padding: 12px 20px; border-radius: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.3); z-index: 999999; font-family: Arial, sans-serif; font-size: 14px; transition: opacity 0.5s;';
    feedback.textContent = '✅ ' + description;
    document.body.appendChild(feedback);
    setTimeout(function() {
      feedback.style.opacity = '0';
      setTimeout(function() { feedback.remove(); }, 500);
    }, 2500);
  }

  console.log('TestCaptive: Content script ready (enterprise mode)');
})();

(() => {
  // src/utils.ts
  var SENSITIVE_INPUT_TYPES = /* @__PURE__ */ new Set([
    "password",
    "credit-card",
    "cc-number",
    "cc-exp",
    "cc-csc",
    "ssn"
  ]);
  var SENSITIVE_AUTOCOMPLETE_VALUES = /* @__PURE__ */ new Set([
    "cc-number",
    "cc-exp",
    "cc-exp-month",
    "cc-exp-year",
    "cc-csc",
    "cc-name",
    "cc-type",
    "new-password",
    "current-password"
  ]);
  var SENSITIVE_NAME_PATTERNS = /password|passwd|pwd|secret|token|ssn|social.?security|credit.?card|card.?number|cvv|cvc|csc|expir/i;
  function isSensitiveField(element) {
    const inputType = element.type?.toLowerCase() || "";
    if (SENSITIVE_INPUT_TYPES.has(inputType)) return true;
    const autocomplete = element.getAttribute("autocomplete")?.toLowerCase() || "";
    if (SENSITIVE_AUTOCOMPLETE_VALUES.has(autocomplete)) return true;
    const name = element.name || "";
    const id = element.id || "";
    const placeholder = element.placeholder || "";
    const ariaLabel = element.getAttribute("aria-label") || "";
    if (SENSITIVE_NAME_PATTERNS.test(name) || SENSITIVE_NAME_PATTERNS.test(id) || SENSITIVE_NAME_PATTERNS.test(placeholder) || SENSITIVE_NAME_PATTERNS.test(ariaLabel)) {
      return true;
    }
    return false;
  }
  function redactIfSensitive(value, element) {
    if (!value) return value;
    if (isSensitiveField(element)) return "[REDACTED]";
    return value;
  }
  var DYNAMIC_ID_PATTERNS = [
    /^:r[0-9a-z]+:$/,
    // React 18+ useId()
    /^react-/,
    // React legacy
    /^ng-/,
    // Angular
    /^_ng[a-z]+-/,
    // Angular CDK
    /^mat-/,
    // Angular Material
    /^cdk-/,
    // Angular CDK
    /^ember\d+$/,
    // Ember
    /^__next/,
    // Next.js
    /^[a-z]{1,3}-[a-f0-9]{4,}$/i,
    // Generic hash-based IDs
    /^[0-9a-f]{8}-[0-9a-f]{4}/,
    // UUID prefix
    /^\d+$/
    // Pure numeric IDs
  ];
  var DYNAMIC_CLASS_PATTERNS = [
    /^css-[a-z0-9]+$/,
    // Emotion CSS-in-JS
    /^sc-[a-zA-Z]+$/,
    // Styled-components
    /^_[a-zA-Z0-9]{5,}$/,
    // CSS Modules hash
    /^svelte-[a-z0-9]+$/,
    // Svelte
    /^tw-[a-z0-9]+$/
    // Tailwind hash
  ];
  function isDynamicId(id) {
    if (!id) return false;
    return DYNAMIC_ID_PATTERNS.some((pattern) => pattern.test(id));
  }
  function isDynamicClass(className) {
    if (!className) return false;
    return DYNAMIC_CLASS_PATTERNS.some((pattern) => pattern.test(className));
  }
  function escapeCSSValue(value) {
    return value.replace(/([!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, "\\$1");
  }
  function generateSelector(element) {
    const testId = element.getAttribute("data-testid") || element.getAttribute("data-test-id");
    if (testId) {
      return `[data-testid="${escapeCSSValue(testId)}"]`;
    }
    const ariaLabel = element.getAttribute("aria-label");
    if (ariaLabel) {
      return `[aria-label="${escapeCSSValue(ariaLabel)}"]`;
    }
    if (element.id && !isDynamicId(element.id)) {
      return `#${escapeCSSValue(element.id)}`;
    }
    const name = element.getAttribute("name");
    if (name) {
      return `${element.tagName.toLowerCase()}[name="${escapeCSSValue(name)}"]`;
    }
    const role = element.getAttribute("role");
    if (role) {
      const text = element.textContent?.trim().substring(0, 50);
      if (text) {
        return `[role="${role}"]`;
      }
    }
    const tag = element.tagName.toLowerCase();
    if (element.className && typeof element.className === "string") {
      const stableClasses = element.className.split(" ").filter((c) => c.trim() && !isDynamicClass(c.trim())).slice(0, 2);
      if (stableClasses.length > 0) {
        let selector = tag + "." + stableClasses.map((c) => escapeCSSValue(c)).join(".");
        const parent2 = element.parentElement;
        if (parent2) {
          const siblings = Array.from(parent2.children).filter(
            (el) => el.tagName === element.tagName
          );
          if (siblings.length > 1) {
            const index = siblings.indexOf(element) + 1;
            selector += `:nth-child(${index})`;
          }
        }
        return selector;
      }
    }
    const parent = element.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter(
        (el) => el.tagName === element.tagName
      );
      if (siblings.length > 1) {
        const index = siblings.indexOf(element) + 1;
        return `${tag}:nth-child(${index})`;
      }
    }
    return tag;
  }
  function generateXPath(element) {
    if (element.id && !isDynamicId(element.id)) {
      return `//*[@id="${element.id}"]`;
    }
    const testId = element.getAttribute("data-testid") || element.getAttribute("data-test-id");
    if (testId) {
      return `//*[@data-testid="${testId}"]`;
    }
    if (element === document.body) {
      return "/html/body";
    }
    if (element === document.documentElement) {
      return "/html";
    }
    let ix = 0;
    const siblings = element.parentNode ? element.parentNode.childNodes : [];
    for (let i = 0; i < siblings.length; i++) {
      const sibling = siblings[i];
      if (sibling === element) {
        const parentXPath = element.parentNode && element.parentNode !== document ? generateXPath(element.parentNode) : "";
        return `${parentXPath}/${element.tagName.toLowerCase()}[${ix + 1}]`;
      }
      if (sibling.nodeType === 1 && sibling.tagName === element.tagName) {
        ix++;
      }
    }
    return "";
  }
  function getShadowHostPath(element) {
    const root = element.getRootNode();
    if (root instanceof ShadowRoot) {
      const host = root.host;
      const hostSelector = generateSelector(host);
      const parentPath = getShadowHostPath(host);
      return parentPath ? `${parentPath} >> ${hostSelector}` : hostSelector;
    }
    return null;
  }
  function getElementInfo(element) {
    const el = element;
    const inputEl = element;
    return {
      tag: el.tagName?.toLowerCase() || "",
      id: el.id || "",
      className: (typeof el.className === "string" ? el.className : "") || "",
      text: el.textContent?.substring(0, 100)?.trim() || "",
      value: inputEl.value || "",
      type: inputEl.type || "",
      name: inputEl.name || "",
      placeholder: inputEl.placeholder || "",
      testid: el.getAttribute("data-testid") || el.getAttribute("data-test-id") || "",
      ariaLabel: el.getAttribute("aria-label") || "",
      role: el.getAttribute("role") || "",
      xpath: generateXPath(element),
      cssSelector: generateSelector(element),
      checked: inputEl.checked,
      href: el.href || "",
      src: el.src || "",
      isContentEditable: el.isContentEditable || false
    };
  }

  // src/content.ts
  (function() {
    "use strict";
    if (window.__TESTCAPTIVE_LOADED__) return;
    window.__TESTCAPTIVE_LOADED__ = true;
    console.log("\u{1F3AF} TestCaptive Content Script Loaded");
    function setDetectionFlag() {
      window.testCaptiveContentScript = true;
      try {
        sessionStorage.setItem("testCaptiveActive", "true");
      } catch (_) {
      }
      try {
        if (document.head && !document.getElementById("__testcaptive_flag__")) {
          const flag = document.createElement("meta");
          flag.id = "__testcaptive_flag__";
          flag.name = "testcaptive-detected";
          flag.content = "true";
          document.head.appendChild(flag);
        }
      } catch (_) {
      }
    }
    setDetectionFlag();
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", setDetectionFlag);
    }
    window.addEventListener("load", setDetectionFlag);
    const MAX_EVENTS = 1e4;
    const SCROLL_DEBOUNCE = 300;
    const FILL_COMMIT_DELAY = 1500;
    let isRecording = false;
    let sessionId = null;
    let recordedEvents = [];
    let rightClickedElement = null;
    let pendingFill = null;
    let fillCommitTimer = null;
    let scrollDebounceTimer = null;
    let lastScrollPosition = { x: 0, y: 0 };
    let lastEmittedEvent = null;
    let lastUrl = window.location.href;
    let originalAlert;
    let originalConfirm;
    let originalPrompt;
    function isTextLikeInput(element) {
      const tag = element.tagName;
      if (tag === "TEXTAREA") return true;
      if (element.isContentEditable) return true;
      if (tag === "INPUT") {
        const type = element.type?.toLowerCase() || "text";
        return ["text", "password", "email", "search", "tel", "url", "number"].includes(type);
      }
      return false;
    }
    function isClickableElement(element) {
      const tag = element.tagName;
      if (tag === "BUTTON") return true;
      if (tag === "A") return true;
      if (tag === "SUMMARY") return true;
      if (element.getAttribute("role") === "button") return true;
      if (element.getAttribute("role") === "link") return true;
      if (element.getAttribute("role") === "tab") return true;
      if (element.getAttribute("role") === "menuitem") return true;
      if (tag === "INPUT") {
        const type = element.type?.toLowerCase();
        return ["submit", "button", "reset", "image"].includes(type || "");
      }
      return false;
    }
    function getElementKey(element) {
      const info = getElementInfo(element);
      return info.testid || info.id || info.name || generateSelector(element);
    }
    function commitPendingFill() {
      if (fillCommitTimer) {
        clearTimeout(fillCommitTimer);
        fillCommitTimer = null;
      }
      if (!pendingFill) return;
      if (pendingFill.value) {
        const safeValue = redactIfSensitive(pendingFill.value, pendingFill.element);
        const elementInfo = { ...pendingFill.elementInfo };
        if (isSensitiveField(pendingFill.element)) {
          elementInfo.value = "[REDACTED]";
        }
        const eventData = {
          type: "fill",
          timestamp: pendingFill.timestamp,
          element: elementInfo,
          page: pendingFill.page,
          sessionId,
          selector: pendingFill.selector,
          inputValue: safeValue,
          position: pendingFill.position,
          iframeContext: pendingFill.iframeContext
        };
        emitEvent(eventData);
      }
      pendingFill = null;
    }
    function scheduleFillCommit() {
      if (fillCommitTimer) clearTimeout(fillCommitTimer);
      fillCommitTimer = setTimeout(commitPendingFill, FILL_COMMIT_DELAY);
    }
    function emitEvent(eventData) {
      if (recordedEvents.length >= MAX_EVENTS) {
        console.warn(`\u26A0\uFE0F TestCaptive: Max events (${MAX_EVENTS}) reached. Stopping capture.`);
        return;
      }
      const now = Date.now();
      if (lastEmittedEvent && lastEmittedEvent.type === eventData.type && lastEmittedEvent.selector === (eventData.selector || "") && now - lastEmittedEvent.timestamp < 150) {
        return;
      }
      recordedEvents.push(eventData);
      lastEmittedEvent = {
        type: eventData.type,
        selector: eventData.selector || "",
        timestamp: now
      };
      try {
        chrome.runtime.sendMessage({
          type: "event-captured",
          data: eventData
        });
      } catch (e) {
        console.warn("TestCaptive: Failed to send event to background:", e);
      }
      console.log("\u{1F4E4} Event captured:", eventData.type, eventData.element?.tag || "", eventData.inputValue || "");
    }
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      switch (message.type) {
        case "start-recording":
          startRecording(message.sessionId);
          sendResponse({ success: true });
          break;
        case "stop-recording":
          commitPendingFill();
          const eventCount = stopRecording();
          sendResponse({ success: true, eventCount });
          break;
        case "ping":
          sendResponse({
            success: true,
            isRecording,
            sessionId,
            eventCount: recordedEvents.length
          });
          break;
        case "add-assertion":
          if (isRecording && message.assertion) {
            addAssertion(message.assertion);
            sendResponse({ success: true });
          } else {
            sendResponse({ success: false, error: "Not recording or invalid assertion" });
          }
          break;
        case "create-text-assertion":
          if (isRecording && rightClickedElement) {
            createTextAssertion(message.assertionType, rightClickedElement);
            sendResponse({ success: true });
          } else {
            sendResponse({ success: false });
          }
          break;
        case "create-simple-assertion":
          if (isRecording && rightClickedElement) {
            createSimpleAssertion(message.assertionType, rightClickedElement);
            sendResponse({ success: true });
          } else {
            sendResponse({ success: false });
          }
          break;
        default:
          sendResponse({ success: false, error: "Unknown message type" });
      }
      return true;
    });
    function startRecording(newSessionId) {
      isRecording = true;
      sessionId = newSessionId;
      recordedEvents = [];
      pendingFill = null;
      if (fillCommitTimer) {
        clearTimeout(fillCommitTimer);
        fillCommitTimer = null;
      }
      lastEmittedEvent = null;
      lastUrl = window.location.href;
      attachEventListeners();
      attachSPAListeners();
      attachDialogInterceptors();
      highlightRecordableElements();
      console.log("\u{1F534} Recording started:", sessionId);
    }
    function stopRecording() {
      isRecording = false;
      const eventCount = recordedEvents.length;
      removeEventListeners();
      removeSPAListeners();
      removeDialogInterceptors();
      removeHighlights();
      console.log("\u23F9\uFE0F Recording stopped. Events captured:", eventCount);
      sessionId = null;
      recordedEvents = [];
      return eventCount;
    }
    function captureEvent(event) {
      if (!isRecording || !sessionId) return;
      try {
        const element = event.target;
        if (!element || !element.tagName) return;
        const eventType = event.type;
        if (eventType === "focus") {
          if (pendingFill && element !== pendingFill.element) {
            commitPendingFill();
          }
          return;
        }
        if (eventType === "blur") {
          if (pendingFill && element === pendingFill.element) {
            commitPendingFill();
          }
          return;
        }
        const rect = element.getBoundingClientRect();
        const elementInfo = getElementInfo(element);
        const iframeContext = getIframeContext();
        const selector = generateSelector(element);
        const shadowPath = getShadowHostPath(element);
        const fullSelector = shadowPath ? `${shadowPath} >> ${selector}` : selector;
        const page = {
          url: window.location.href,
          title: document.title,
          scrollX: window.scrollX,
          scrollY: window.scrollY
        };
        const position = {
          x: Math.round(rect.left + window.scrollX),
          y: Math.round(rect.top + window.scrollY),
          width: Math.round(rect.width),
          height: Math.round(rect.height)
        };
        if (eventType === "input") {
          handleSmartInput(element, elementInfo, fullSelector, page, position, iframeContext || void 0);
          return;
        }
        if (eventType === "change") {
          handleSmartChange(element, elementInfo, fullSelector, page, position, iframeContext || void 0);
          return;
        }
        if (eventType === "click") {
          handleSmartClick(event, element, elementInfo, fullSelector, page, position, iframeContext || void 0);
          return;
        }
        if (eventType === "dblclick") {
          commitPendingFill();
          emitEvent({
            type: "dblclick",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            element: elementInfo,
            page,
            sessionId,
            selector: fullSelector,
            position,
            iframeContext: iframeContext || void 0
          });
          return;
        }
        if (eventType === "keydown") {
          handleSmartKeydown(event, element, elementInfo, fullSelector, page, position, iframeContext || void 0);
          return;
        }
        if (eventType === "submit") {
          commitPendingFill();
          emitEvent({
            type: "submit",
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            element: elementInfo,
            page,
            sessionId,
            selector: fullSelector,
            position,
            iframeContext: iframeContext || void 0
          });
          return;
        }
      } catch (error) {
        console.error("TestCaptive: Error capturing event:", error);
      }
    }
    function handleSmartClick(event, element, elementInfo, selector, page, position, iframeContext) {
      if (isTextLikeInput(element)) {
        if (pendingFill && pendingFill.element === element) {
          return;
        }
        commitPendingFill();
        pendingFill = {
          element,
          selector,
          elementInfo,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          value: element.value || "",
          page,
          position,
          iframeContext
        };
        return;
      }
      if (element.tagName === "SELECT") {
        return;
      }
      commitPendingFill();
      if (isSensitiveField(element)) {
        elementInfo.value = "[REDACTED]";
      }
      emitEvent({
        type: "click",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        element: elementInfo,
        page,
        sessionId,
        selector,
        position,
        clickPosition: {
          clientX: event.clientX,
          clientY: event.clientY
        },
        iframeContext
      });
    }
    function handleSmartInput(element, elementInfo, selector, page, position, iframeContext) {
      const inputEl = element;
      if (element.tagName === "SELECT" || inputEl.type === "checkbox" || inputEl.type === "radio") {
        return;
      }
      const currentValue = inputEl.value || element.textContent || "";
      if (pendingFill && pendingFill.element === element) {
        pendingFill.value = currentValue;
        pendingFill.timestamp = (/* @__PURE__ */ new Date()).toISOString();
        scheduleFillCommit();
      } else {
        commitPendingFill();
        pendingFill = {
          element,
          selector,
          elementInfo,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          value: currentValue,
          page,
          position,
          iframeContext
        };
        scheduleFillCommit();
      }
    }
    function handleSmartChange(element, elementInfo, selector, page, position, iframeContext) {
      const inputEl = element;
      const tag = element.tagName;
      if (tag === "SELECT") {
        commitPendingFill();
        const selectEl = element;
        const selectedOptions = Array.from(selectEl.selectedOptions).map((o) => o.text);
        elementInfo.selectedOptions = selectedOptions;
        emitEvent({
          type: "select",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          value: selectEl.value,
          inputValue: selectEl.value,
          position,
          iframeContext
        });
        return;
      }
      if (inputEl.type === "checkbox" || inputEl.type === "radio") {
        commitPendingFill();
        elementInfo.checked = inputEl.checked;
        emitEvent({
          type: "check",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          value: String(inputEl.checked),
          position,
          iframeContext
        });
        return;
      }
      if (inputEl.type === "file" && inputEl.files && inputEl.files.length > 0) {
        commitPendingFill();
        emitEvent({
          type: "file-upload",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          files: Array.from(inputEl.files).map((f) => ({
            name: f.name,
            size: f.size,
            type: f.type
          })),
          position,
          iframeContext
        });
        return;
      }
    }
    function handleSmartKeydown(event, element, elementInfo, selector, page, position, iframeContext) {
      const key = event.key;
      if (key === "Tab") {
        commitPendingFill();
        return;
      }
      if (key === "Enter") {
        if (isTextLikeInput(element)) {
          commitPendingFill();
        }
        emitEvent({
          type: "keydown",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          value: "Enter",
          position,
          iframeContext
        });
        return;
      }
      if (key === "Escape") {
        commitPendingFill();
        emitEvent({
          type: "keydown",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          value: "Escape",
          position,
          iframeContext
        });
        return;
      }
      const isShortcut = event.ctrlKey || event.metaKey || event.altKey;
      if (isShortcut) {
        const parts = [];
        if (event.ctrlKey) parts.push("Control");
        if (event.altKey) parts.push("Alt");
        if (event.shiftKey) parts.push("Shift");
        if (event.metaKey) parts.push("Meta");
        parts.push(key);
        emitEvent({
          type: "keydown",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          value: parts.join("+"),
          position,
          iframeContext
        });
        return;
      }
      const navigationKeys = /* @__PURE__ */ new Set([
        "ArrowUp",
        "ArrowDown",
        "ArrowLeft",
        "ArrowRight",
        "Home",
        "End",
        "PageUp",
        "PageDown",
        "F1",
        "F2",
        "F3",
        "F4",
        "F5",
        "F6",
        "F7",
        "F8",
        "F9",
        "F10",
        "F11",
        "F12"
      ]);
      if (navigationKeys.has(key) && !isTextLikeInput(element)) {
        emitEvent({
          type: "keydown",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: elementInfo,
          page,
          sessionId,
          selector,
          value: key,
          position,
          iframeContext
        });
      }
    }
    function handleScroll() {
      if (!isRecording || !sessionId) return;
      if (scrollDebounceTimer) clearTimeout(scrollDebounceTimer);
      scrollDebounceTimer = setTimeout(() => {
        const currentScroll = { x: window.scrollX, y: window.scrollY };
        const dx = Math.abs(currentScroll.x - lastScrollPosition.x);
        const dy = Math.abs(currentScroll.y - lastScrollPosition.y);
        if (dx < 200 && dy < 200) return;
        lastScrollPosition = currentScroll;
        const eventData = {
          type: "scroll",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: {
            tag: "window",
            id: "",
            className: "",
            text: "",
            value: "",
            type: "",
            name: "",
            placeholder: "",
            testid: "",
            ariaLabel: "",
            role: "",
            xpath: ""
          },
          page: {
            url: window.location.href,
            title: document.title,
            scrollX: window.scrollX,
            scrollY: window.scrollY
          },
          sessionId,
          scrollPosition: currentScroll
        };
        emitEvent(eventData);
      }, SCROLL_DEBOUNCE);
    }
    let dragSourceElement = null;
    function handleDragStart(event) {
      if (!isRecording) return;
      dragSourceElement = event.target;
    }
    function handleDrop(event) {
      if (!isRecording || !sessionId || !dragSourceElement) return;
      const dropTarget = event.target;
      const eventData = {
        type: "drag-drop",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        element: getElementInfo(dropTarget),
        page: {
          url: window.location.href,
          title: document.title
        },
        sessionId,
        selector: generateSelector(dropTarget),
        dragSource: generateSelector(dragSourceElement),
        dropTarget: generateSelector(dropTarget)
      };
      emitEvent(eventData);
      dragSourceElement = null;
    }
    let hoverTimer = null;
    function handleMouseEnter(event) {
      if (!isRecording || !sessionId) return;
      const element = event.target;
      if (!isInteractiveHoverTarget(element)) return;
      if (hoverTimer) clearTimeout(hoverTimer);
      hoverTimer = setTimeout(() => {
        const eventData = {
          type: "hover",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          element: getElementInfo(element),
          page: {
            url: window.location.href,
            title: document.title
          },
          sessionId,
          selector: generateSelector(element)
        };
        emitEvent(eventData);
      }, 500);
    }
    function handleMouseLeave() {
      if (hoverTimer) {
        clearTimeout(hoverTimer);
        hoverTimer = null;
      }
    }
    function isInteractiveHoverTarget(element) {
      const role = element.getAttribute("role");
      if (role && ["menu", "menubar", "menuitem", "tooltip", "listbox", "option"].includes(role)) {
        return true;
      }
      const tag = element.tagName.toLowerCase();
      if (tag === "nav" || tag === "menu") return true;
      if (element.getAttribute("aria-haspopup")) return true;
      return false;
    }
    function onSPANavigation() {
      if (!isRecording || !sessionId) return;
      const currentUrl = window.location.href;
      if (currentUrl === lastUrl) return;
      const eventData = {
        type: "spa-navigation",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        element: {
          tag: "window",
          id: "",
          className: "",
          text: "",
          value: "",
          type: "",
          name: "",
          placeholder: "",
          testid: "",
          ariaLabel: "",
          role: "",
          xpath: ""
        },
        page: {
          url: currentUrl,
          title: document.title
        },
        sessionId
      };
      emitEvent(eventData);
      lastUrl = currentUrl;
    }
    const originalPushState = history.pushState.bind(history);
    const originalReplaceState = history.replaceState.bind(history);
    function patchedPushState(state, title, url) {
      originalPushState(state, title, url);
      setTimeout(onSPANavigation, 0);
    }
    function patchedReplaceState(state, title, url) {
      originalReplaceState(state, title, url);
      setTimeout(onSPANavigation, 0);
    }
    function attachSPAListeners() {
      window.addEventListener("popstate", onSPANavigation);
      window.addEventListener("hashchange", onSPANavigation);
      history.pushState = patchedPushState;
      history.replaceState = patchedReplaceState;
    }
    function removeSPAListeners() {
      window.removeEventListener("popstate", onSPANavigation);
      window.removeEventListener("hashchange", onSPANavigation);
      history.pushState = originalPushState;
      history.replaceState = originalReplaceState;
    }
    function attachDialogInterceptors() {
      originalAlert = window.alert;
      originalConfirm = window.confirm;
      originalPrompt = window.prompt;
      window.alert = function(message) {
        captureDialog("alert", String(message ?? ""), "");
        return originalAlert.call(window, message);
      };
      window.confirm = function(message) {
        const result = originalConfirm.call(window, message);
        captureDialog("confirm", message || "", String(result));
        return result;
      };
      window.prompt = function(message, defaultValue) {
        const result = originalPrompt.call(window, message, defaultValue);
        captureDialog("prompt", message || "", result || "");
        return result;
      };
    }
    function removeDialogInterceptors() {
      if (originalAlert) window.alert = originalAlert;
      if (originalConfirm) window.confirm = originalConfirm;
      if (originalPrompt) window.prompt = originalPrompt;
    }
    function captureDialog(dialogType, message, response) {
      if (!isRecording || !sessionId) return;
      const eventData = {
        type: "dialog",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        element: {
          tag: "dialog",
          id: "",
          className: "",
          text: message,
          value: "",
          type: dialogType,
          name: "",
          placeholder: "",
          testid: "",
          ariaLabel: "",
          role: "alertdialog",
          xpath: ""
        },
        page: {
          url: window.location.href,
          title: document.title
        },
        sessionId,
        dialogType,
        dialogMessage: message,
        dialogResponse: response
      };
      emitEvent(eventData);
    }
    function getIframeContext() {
      try {
        if (window === window.top) return null;
        const frame = window.frameElement;
        if (frame) {
          const id = frame.id || frame.getAttribute("name") || "";
          const src = frame.getAttribute("src") || "";
          return id || src || "anonymous-iframe";
        }
        return "cross-origin-iframe";
      } catch (_) {
        return "cross-origin-iframe";
      }
    }
    const coreEventTypes = ["click", "dblclick", "input", "change", "submit", "focus", "blur", "keydown"];
    const eventHandlers = {};
    function attachEventListeners() {
      coreEventTypes.forEach((eventType) => {
        eventHandlers[eventType] = (e) => captureEvent(e);
        document.addEventListener(eventType, eventHandlers[eventType], true);
      });
      window.addEventListener("scroll", handleScroll, { passive: true });
      document.addEventListener("dragstart", handleDragStart, true);
      document.addEventListener("drop", handleDrop, true);
      document.addEventListener("mouseenter", handleMouseEnter, true);
      document.addEventListener("mouseleave", handleMouseLeave, true);
      document.addEventListener("contextmenu", captureRightClick, true);
      console.log("\u{1F3AF} Event listeners attached (enterprise mode)");
    }
    function removeEventListeners() {
      coreEventTypes.forEach((eventType) => {
        if (eventHandlers[eventType]) {
          document.removeEventListener(eventType, eventHandlers[eventType], true);
        }
      });
      window.removeEventListener("scroll", handleScroll);
      document.removeEventListener("dragstart", handleDragStart, true);
      document.removeEventListener("drop", handleDrop, true);
      document.removeEventListener("mouseenter", handleMouseEnter, true);
      document.removeEventListener("mouseleave", handleMouseLeave, true);
      document.removeEventListener("contextmenu", captureRightClick, true);
      if (scrollDebounceTimer) clearTimeout(scrollDebounceTimer);
      if (hoverTimer) clearTimeout(hoverTimer);
      console.log("\u{1F3AF} Event listeners removed");
    }
    function highlightRecordableElements() {
      if (!isRecording) return;
      const style = document.createElement("style");
      style.id = "testcaptive-highlight-style";
      style.textContent = `
      .testcaptive-recordable {
        outline: 2px dashed #4CAF50 !important;
        outline-offset: 2px !important;
      }
      .testcaptive-recordable:hover {
        outline: 2px solid #4CAF50 !important;
        background-color: rgba(76, 175, 80, 0.1) !important;
      }
    `;
      document.head?.appendChild(style);
      const selector = 'button, input, select, textarea, a[href], [onclick], [role="button"], [tabindex], [draggable="true"], [contenteditable="true"]';
      document.querySelectorAll(selector).forEach((el) => {
        el.classList.add("testcaptive-recordable");
      });
      console.log("\u2728 Interactive elements highlighted");
    }
    function removeHighlights() {
      const style = document.getElementById("testcaptive-highlight-style");
      if (style) style.remove();
      document.querySelectorAll(".testcaptive-recordable").forEach((el) => {
        el.classList.remove("testcaptive-recordable");
      });
    }
    function captureRightClick(event) {
      if (!isRecording) return;
      rightClickedElement = event.target;
    }
    function createTextAssertion(assertionType, element) {
      const elementInfo = getElementInfo(element);
      let expectedValue = "";
      if (assertionType === "assert-text-equals" || assertionType === "assert-text-contains") {
        expectedValue = prompt(
          `Enter expected text for ${assertionType}:`,
          element.textContent?.trim() || ""
        ) || "";
        if (!expectedValue) return;
      } else if (assertionType === "assert-url-contains") {
        expectedValue = prompt("Enter expected URL part:", window.location.pathname) || "";
        if (!expectedValue) return;
      }
      const assertion = {
        type: assertionType.replace("assert-", ""),
        description: getAssertionDescription(assertionType, expectedValue, elementInfo),
        expectedValue,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        element: elementInfo
      };
      addAssertion(assertion);
    }
    function createSimpleAssertion(assertionType, element) {
      const elementInfo = getElementInfo(element);
      const assertion = {
        type: assertionType.replace("assert-", ""),
        description: getAssertionDescription(assertionType, null, elementInfo),
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        element: elementInfo
      };
      addAssertion(assertion);
    }
    function getAssertionDescription(type, value, elementInfo) {
      const elementDesc = elementInfo.testid ? `[testid="${elementInfo.testid}"]` : elementInfo.id ? `#${elementInfo.id}` : elementInfo.text ? `"${elementInfo.text.substring(0, 30)}"` : elementInfo.tag;
      switch (type) {
        case "assert-text-equals":
          return `Assert ${elementDesc} text equals "${value}"`;
        case "assert-text-contains":
          return `Assert ${elementDesc} text contains "${value}"`;
        case "assert-visible":
          return `Assert ${elementDesc} is visible`;
        case "assert-not-visible":
          return `Assert ${elementDesc} is not visible`;
        case "assert-enabled":
          return `Assert ${elementDesc} is enabled`;
        case "assert-disabled":
          return `Assert ${elementDesc} is disabled`;
        case "assert-url-contains":
          return `Assert URL contains "${value}"`;
        default:
          return `Assert ${type}`;
      }
    }
    function addAssertion(assertion) {
      if (!isRecording || !sessionId) return;
      const assertionEvent = {
        type: "assertion",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        sessionId,
        assertion,
        element: assertion.element || {
          tag: "assertion",
          id: "",
          className: "",
          text: "",
          value: "",
          type: "",
          name: "",
          placeholder: "",
          testid: "",
          ariaLabel: "",
          role: "",
          xpath: ""
        },
        page: {
          url: window.location.href,
          title: document.title
        }
      };
      emitEvent(assertionEvent);
      console.log("\u2705 Assertion added:", assertion.type);
      showAssertionFeedback(assertion.description);
    }
    function showAssertionFeedback(description) {
      const feedback = document.createElement("div");
      feedback.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #4CAF50;
      color: white;
      padding: 12px 20px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      z-index: 999999;
      font-family: Arial, sans-serif;
      font-size: 14px;
      transition: opacity 0.5s;
    `;
      feedback.textContent = `\u2705 ${description}`;
      document.body.appendChild(feedback);
      setTimeout(() => {
        feedback.style.opacity = "0";
        setTimeout(() => feedback.remove(), 500);
      }, 2500);
    }
    console.log("TestCaptive: Content script ready (enterprise mode)");
  })();
})();
